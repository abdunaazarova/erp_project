import 'package:erp_project/pages/korzinka.dart';
import 'package:erp_project/pages/statistics.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:erp_project/pages/add_product.dart';
import 'package:erp_project/pages/first_page.dart';
import 'package:erp_project/pages/orders.dart';
import 'package:erp_project/pages/super_admin.dart';
import 'package:erp_project/pages/login.dart';
import 'package:erp_project/pages/product_page.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final GoRouter _router = GoRouter(
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => LoginPage(),
      ),
      GoRoute(
        path: '/dashboard',
        builder: (context, state) => ProductGridScreen(),
      ),
      GoRoute(
        path: '/first',
        builder: (context, state) => FirstPage(),
      ),
      GoRoute(
        path: '/orders',
        builder: (context, state) => OrdersPage(),
      ),
      GoRoute(
        path: '/add-product',
        builder: (context, state) => AddProduct(),
      ),
      GoRoute(
        path: '/super-admin',
        builder: (context, state) => SuperAdmin(),
      ),
      GoRoute(
        path: '/korzinka',
        builder: (context, state) => ShoppingCartScreen(),
      ),
      GoRoute(
        path: '/statistics',
        builder: (context, state) => StatisticsScreen(),
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      routerConfig: _router,
    );
  }
}
