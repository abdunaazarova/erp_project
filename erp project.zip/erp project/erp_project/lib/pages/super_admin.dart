import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SuperAdmin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
               context.go('/first');
            },
            icon: Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(
                  color: Colors.grey,
                  width: 0.1,
                ),
              ),
              child: Center(
                child: Icon(
                  Icons.chevron_left,
                  color: Colors.black,
                  size: 28,
                ),
              ),
            ),
          ),
          backgroundColor: Colors.white,
          title: Text(
            'SweeTrack',
            style: TextStyle(
              fontSize: 25,
              color: Color.fromRGBO(157, 67, 2, 1),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.notifications),
              iconSize: 30,
              color: Color.fromRGBO(157, 67, 2, 1),
            ),
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.person),
              iconSize: 30,
              color: Color.fromRGBO(157, 67, 2, 1),
            )
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 20),
                child: Text(
                  "Permission for entering information to",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(157, 67, 2, 1), // Text color
                  ),
                ),
              ),
              SizedBox(height: 20),
              CheckboxExample(),
              SizedBox(height: 20),
              Center(
                child: Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(70),
                    border: Border.all(
                      width: 2.0,
                      color: Color.fromRGBO(157, 67, 2, 1),
                    ),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      // Handle user tap to select or capture an image
                      // For example, you can open a dialog or navigate to a new page
                    },
                    child: Icon(
                      Icons.add_a_photo,
                      size: 50,
                      color: Color.fromRGBO(157, 67, 2, 1),
                    ),
                  ),
                ),
              ),
              InputValidationExample(),
            ],
          ),
        ),
      ),
    );
  }
}

class CheckboxExample extends StatefulWidget {
  @override
  _CheckboxExampleState createState() => _CheckboxExampleState();
}

class _CheckboxExampleState extends State<CheckboxExample> {
  bool _isChecked1 = false;
  bool _isChecked2 = false;
  bool _isChecked3 = false;
  bool _isChecked4 = false;
  bool _isChecked5 = false;
  bool _isChecked6 = false;


  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        children: [
          Column(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked1,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked1 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'Dashboard',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 0),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked2,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked2 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'Users',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 15),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked3,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked3 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'Product',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Column(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 40),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked4,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked4 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'Supplier page',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 55),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked5,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked5 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'W-management',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
              Padding(

                padding: EdgeInsets.only(left: 5),
                child: Row(
                  children: [
                    Checkbox(
                      value: _isChecked6,
                      onChanged: (newValue) {
                        setState(() {
                          _isChecked6 = newValue!;
                        });
                      },
                      activeColor: Color.fromRGBO(157, 67, 2, 1),
                    ),
                    Text(
                      'W-order',
                      style: TextStyle(
                        color: Color.fromRGBO(157, 67, 2, 1), // Text color
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class InputValidationExample extends StatefulWidget {
  @override
  _InputValidationExampleState createState() => _InputValidationExampleState();
}

class _InputValidationExampleState extends State<InputValidationExample> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? _inputValue1;
  String? _inputValue2;
  String? _inputValue3;
  String? _inputValue4;
  String? _inputValue5;
  String? _inputValue6;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Name*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(10), // Adjust the radius as needed
                  color: Colors.grey[200],
                  border: Border.all(
                    width: 3,
                    color: Color.fromRGBO(229, 201, 149, 1),
                  ) // Example background color
                  ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue1 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Surname*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(10), // Adjust the radius as needed
                color: Colors.grey[200],
                border: Border.all(
                  width: 3,
                  color: Color.fromRGBO(229, 201, 149, 1),
                ), // Example background color
              ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue2 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),

              ),
            ),
            SizedBox(height: 20),
            Text(
              'ID for usage*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(10), // Adjust the radius as needed
                color: Colors.grey[200],
                border: Border.all(
                  width: 3,
                  color: Color.fromRGBO(229, 201, 149, 1),
                ), // Example background color
              ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue3 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Position*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(10), // Adjust the radius as needed
                color: Colors.grey[200],
                border: Border.all(
                  width: 3,
                  color: Color.fromRGBO(229, 201, 149, 1),
                ), // Example background color
              ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue4 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Phone number*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(10), // Adjust the radius as needed
                color: Colors.grey[200],
                border: Border.all(
                  width: 3,
                  color: Color.fromRGBO(229, 201, 149, 1),
                ), // Example background color
              ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue5 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(

              'Email*',
              style: TextStyle(
                color: Color.fromRGBO(157, 67, 2, 1), // Text color
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            SizedBox(height: 10),
            Container(
              height: 43,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.circular(10), // Adjust the radius as needed
                color: Colors.grey[200],
                border: Border.all(
                  width: 3,
                  color: Color.fromRGBO(229, 201, 149, 1),
                ), // Example background color
              ),
              child: TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field is required';
                  }
                  return null;
                },
                onSaved: (value) {
                  _inputValue6 = value;
                },
                decoration: InputDecoration(
                  filled: true,
                  fillColor:
                      Color.fromRGBO(229, 201, 149, 1), // Set background color
                ),
              ),
            ),
            SizedBox(height: 20),
            Container(
              width: 100,
              height: 40,
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    // Perform your desired action with the input values
                    print('Input value 1: $_inputValue1');
                    print('Input value 2: $_inputValue2');
                    print('Input value 3: $_inputValue3');
                    print('Input value 4: $_inputValue4');
                    print('Input value 5: $_inputValue5');
                    print('Input value 6: $_inputValue6');
                  }
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(
                      Color.fromRGBO(157, 67, 2, 1)),
                ),
                child: Text(
                  'Submit',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
