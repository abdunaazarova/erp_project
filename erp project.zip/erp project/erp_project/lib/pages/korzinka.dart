import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ShoppingCartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            context.go('/dashboard');
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_horiz, color: Colors.black),
            onPressed: () {},
          )
        ],
        title: Text(
          'Mahsulotlar',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: DefaultTabController(
        length: 2,
        child: Column(
          children: <Widget>[
            Container(
              color: Colors.white,
              child: TabBar(
                labelColor: Colors.black,
                unselectedLabelColor: Colors.grey,
                indicatorColor: Colors.black,
                tabs: [
                  Tab(text: 'Mahsulotlar savati'),
                  Tab(text: 'Mijoz ma\'lumotlari'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: <Widget>[
                  ShoppingCartTab(),
                  Center(child: Text('Mijoz ma\'lumotlari')),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Mahsulotlar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.archive),
            label: 'Arxiv',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
        selectedItemColor: Colors.black,
      ),
    );
  }
}

class ShoppingCartTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Xarid qilish savati',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          SizedBox(height: 8),
          Text(
            'Sizning savatingizda 3 ta mahsulot bor',
            style: TextStyle(color: Colors.grey),
          ),
          SizedBox(height: 16),
          ShoppingCartItem(
            productName: 'Cappuccino',
            productDescription: 'with Chocolate',
            productQuantity: 1,
            productPrice: 4.53,
          ),
          ShoppingCartItem(
            productName: 'Cappuccino',
            productDescription: 'with Chocolate',
            productQuantity: 1,
            productPrice: 4.53,
          ),
          ShoppingCartItem(
            productName: 'Cappuccino',
            productDescription: 'with Chocolate',
            productQuantity: 1,
            productPrice: 4.53,
          ),
          Spacer(),
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Mahsulot narxi', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('\$4.53', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Umumiy to\'lov', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('\$5.53', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}

class ShoppingCartItem extends StatelessWidget {
  final String productName;
  final String productDescription;
  final int productQuantity;
  final double productPrice;

  const ShoppingCartItem({
    Key? key,
    required this.productName,
    required this.productDescription,
    required this.productQuantity,
    required this.productPrice,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Image.network('https://via.placeholder.com/50', height: 50, width: 50),
        title: Text(productName),
        subtitle: Text(productDescription),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.remove_circle_outline),
              onPressed: () {},
            ),
            Text('$productQuantity'),
            IconButton(
              icon: Icon(Icons.add_circle_outline),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () {},
            ),
          ],
        ),
      ),
    );
  }
}
