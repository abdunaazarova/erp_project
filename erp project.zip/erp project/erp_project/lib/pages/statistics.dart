import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:erp_project/pages/order_adding.dart';
import 'package:go_router/go_router.dart';
class StatisticsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            context.go('/dashboard');
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_horiz, color: Colors.black),
            onPressed: () {},
          )
        ],
        title: Text(
          'Statistika',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            StatisticCard(
              amount: '\$6,564.34',
              title: 'Umumiy Statistika',
              icon: Icons.wallet,
            ),
            StatisticCard(
              amount: '\$6,564.34',
              title: 'Daromadlar',
              icon: Icons.attach_money,
            ),
            StatisticCard(
              amount: '\$6,564.34',
              title: 'Xarajatlar',
              icon: Icons.money_off,
            ),
            SizedBox(height: 16),
            ToggleButtons(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Oylik'),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Haftalik'),
                ),
              ],
              isSelected: [true, false],
              onPressed: (int index) {},
            ),
            SizedBox(height: 16),
            Expanded(
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: SideTitles(showTitles: false),
                    bottomTitles: SideTitles(showTitles: true),
                  ),
                  borderData: FlBorderData(show: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        FlSpot(0, 1),
                        FlSpot(1, 3),
                        FlSpot(2, 2),
                        FlSpot(3, 5),
                        FlSpot(4, 3),
                        FlSpot(5, 4),
                        FlSpot(6, 3),
                        FlSpot(7, 5),
                        FlSpot(8, 6),
                        FlSpot(9, 4),
                        FlSpot(10, 5),
                        FlSpot(11, 7),
                      ],
                      isCurved: true,
                      colors: [Colors.orange],
                      barWidth: 5,
                      belowBarData: BarAreaData(
                        show: true,
                        colors: [
                          Colors.orange.withOpacity(0.3),
                          Colors.orange.withOpacity(0.1),
                        ],
                      ),
                      dotData: FlDotData(show: false),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Statistika',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.room_service),
            label: 'Xizmatlar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
        selectedItemColor: Colors.black,
      ),
    );
  }
}

class StatisticCard extends StatelessWidget {
  final String amount;
  final String title;
  final IconData icon;

  const StatisticCard({
    Key? key,
    required this.amount,
    required this.title,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        leading: Icon(icon, color: Colors.orange, size: 40),
        title: Text(amount, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        subtitle: Text(title),
      ),
    );
  }
}
