import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AddProduct extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'add product',
      home: Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text(
              'Add Product',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          leading: IconButton(
            onPressed: () {
              context.go('/first');
            },
            icon: Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(
                  color: Colors.grey,
                  width: 0.1,
                ),
              ),
              child: Center(
                child: Icon(
                  Icons.chevron_left,
                  color: Colors.black,
                  size: 28,
                ),
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                // Handle back button press
              },
              icon: Container(
                width: 35,
                height: 35,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(
                    color: Colors.grey,
                    width: 0.1,
                  ),
                ),
                child: Center(
                  child: Icon(
                    Icons.more_horiz,
                    color: Colors.black,
                    size: 28,
                  ),
                ),
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 15),
              FileUploadContainer(),
              SizedBox(height: 5),
              AddProductPage(),
            ],
          ),
        ), // Placing AddProductPage here
      ),
    );
  }
}

class FileUploadContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      height: 150,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Icon(Icons.cloud_upload,
              size: 70, color: Color.fromRGBO(157, 67, 2, 1)),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Drag & drop files or ',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  )),
              Text("Browse",
                  style: TextStyle(
                    color: Color.fromRGBO(157, 67, 2, 1),
                    fontWeight: FontWeight.bold,
                  )),
            ],
          ),
        ],
      ),
    );
  }
}


class AddProductPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(height: 20.0),
          Text('Product Name:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product name',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Product ID:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product ID',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Supplier Name:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter supplier name',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Supplier ID:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter supplier ID',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Description:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product description',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Price:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product price',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Quantity:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product quantity',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          Text('Category:', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8.0),
          TextField(
            decoration: InputDecoration(
              hintText: 'Enter product category',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () {
              // Add product functionality
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromRGBO(157, 67, 2, 1)), // Set the background color
              minimumSize: MaterialStateProperty.all<Size>(
                  Size(100, 50)), // Set width and height
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(10), // Set the border radius here
                ),
              ),
            ),
            child: Text('Add Product',
                style: TextStyle(
                  color: Colors.white,
                )),
          ),
        ],
      ),
    );
  }
}
