import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class FirstPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'SweeTrack',
          style: TextStyle(
            fontSize: 25,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {},
            iconSize: 30,
            color: Colors.black,
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Color.fromRGBO(244, 218, 169, 100),
          padding: EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // First Icon and Text
                  _buildIconWithText(
                    Icons.home,
                    'Dashboard',
                    context,
                    '/dashboard',
                  ),
                  // Second Icon and Text
                  _buildIconWithText(
                    Icons.insert_chart,
                    'Statistics',
                    context,
                    '/statistics',
                  ),
                ],
              ),
              SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Third Icon and Text
                  _buildIconWithText(
                    Icons.shopping_bag,
                    'Add product',
                    context,
                    '/add-product',
                  ),
                  // Fourth Icon and Text
                  _buildIconWithText(
                    Icons.storefront,
                    'Orders',
                    context,
                    '/orders',
                  ),
                ],
              ),
              SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Fifth Icon and Text
                  _buildIconWithText(
                    Icons.receipt,
                    'W-house Order',
                    context,
                    '/korzinka',
                  ),
                  // Sixth Icon and Text
                  _buildIconWithText(
                    Icons.person,
                    'User',
                    context,
                    '/super-admin',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xffefcf95),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            IconButton(
              icon: Icon(Icons.settings),
              onPressed: () {
                // Add your onPressed logic here
              },
              color: Color(0xff843108),
              iconSize: 30,
            ),
            Text("Settings",
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.black,
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildIconWithText(
      IconData icon, String text, BuildContext context, String? route) {
    return GestureDetector(
      onTap: () {
        if (route != null) {
          context.go(route);
        }
      },
      child: Column(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Color.fromRGBO(167, 57, 2, 100),
            ),
            child: Icon(
              icon,
              color: Colors.black,
              size: 50,
            ),
          ),
          SizedBox(height: 10),
          Text(
            text,
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
