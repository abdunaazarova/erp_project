import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

void main() {
  runApp(LoginPage());
}

class LoginPage extends StatelessWidget {
  final Color appBackgroundColor = Color(0xfff4daa9);
  LoginPage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          backgroundColor: appBackgroundColor,
          body: Center(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 120),
                  child: Text(
                    "SweeTrack",
                    style: TextStyle(
                      color: Color(0xff743203),
                      fontSize: 40,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      TextField(
                          decoration: InputDecoration(
                        labelText: 'id',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color: Color(
                                0xff743203), // You can set border color here
                            width: 2.0,
                          ),
                        ),
                      )),
                      SizedBox(height: 20),
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'password',
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: Color(0xff743203),
                                width: 2.0,
                              )),
                        ),
                      ),
                      SizedBox(height: 40),
                      SizedBox(
                        width: 150,
                        height: 50,
                        child: TextButton(
                            onPressed: () {
                              context.go('/first');
                            },
                            child: Text("LOGIN",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                )),
                            style: TextButton.styleFrom(
                                backgroundColor: Color(0xff743203),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5),
                                ))),
                      )
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}